/*******************************************************************************
 * Copyright (c) 2010, 2011 SAP AG and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Dimo Stoilov (SAP AG) - initial API and implementation
 *******************************************************************************/
package org.eclipse.libra.facet.test;

import static org.eclipse.libra.facet.OSGiBundleFacetUtils.BUILD_PROPERTIES;
import static org.eclipse.libra.facet.OSGiBundleFacetUtils.OSGI_BUNDLE_FACET_42;
import static org.eclipse.libra.facet.OSGiBundleFacetUtils.WEB_CONTEXT_PATH_HEADER;
import static org.eclipse.libra.facet.OSGiBundleFacetUtils.getBundleProjectDescription;
import static org.eclipse.wst.common.tests.OperationTestCase.deleteAllProjects;
import static org.eclipse.wst.common.tests.OperationTestCase.waitOnJobs;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.etools.common.test.apitools.ProjectUnzipUtil;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.libra.facet.OSGiBundleFacetInstallConfig;
import org.eclipse.libra.facet.OSGiBundleFacetUninstallConfig;
import org.eclipse.libra.facet.OSGiBundleFacetUninstallStrategy;
import org.eclipse.libra.facet.ui.operations.ConvertProjectsToBundlesOperation;
import org.eclipse.pde.core.project.IBundleClasspathEntry;
import org.eclipse.pde.core.project.IBundleProjectDescription;
import org.eclipse.pde.core.project.IPackageExportDescription;
import org.eclipse.pde.core.project.IPackageImportDescription;
import org.eclipse.pde.internal.core.PDECore;
import org.eclipse.pde.internal.core.natures.PDE;
import org.eclipse.wst.common.project.facet.core.FacetedProjectFramework;
import org.eclipse.wst.common.project.facet.core.IFacetedProject;
import org.eclipse.wst.common.project.facet.core.IFacetedProjectWorkingCopy;
import org.eclipse.wst.common.project.facet.core.IProjectFacet;
import org.eclipse.wst.common.project.facet.core.IProjectFacetVersion;
import org.eclipse.wst.common.project.facet.core.ProjectFacetsManager;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.osgi.framework.Constants;

public class WabConversionTest {
	
	private static final NullProgressMonitor monitor = new NullProgressMonitor();
	
	private static final String WEB_PRJ_LOCATION = "resources/testWeb.zip";
	private static final String JAVA_PRJ_LOCATION = "resources/testJava.zip";
	private static final String JPA_PRJ_LOCATION = "resources/testJPA.zip";
	private static final String JPA_UTILITY_PRJ_LOCATION = "resources/testJPAwithUtility.zip";
	private static final String SIMPLE_PRJ_LOCATION = "resources/testSimple.zip";
	private static final String WEB_PRJ_NAME = "testWeb";
	private static final String JAVA_PRJ_NAME = "testJava";
	private static final String JPA_PRJ_NAME = "testJPA";
	private static final String JPA_CREATE_PRJ_NAME = "testJPACreate";
	private static final String JPA_UTILITY_CREATE_PRJ_NAME = "testJPAUtilityCreate";
	private static final String JPA_UTILITY_PRJ_NAME = "testJPAwithUtility";
	private static final String SIMPLE_PRJ_NAME = "testSimple";
	private static final String WEB_REFERRING_JAVA_PRJ_LOCATION = "resources/testWebReferringJava.zip";
	private static final String WEB_REFERRING_JAVA_PRJ_NAME = "testWebReferringJava";
	private static final String JAVA_REFERRED_PRJ_LOCATION = "resources/testJavaReferred.zip";
	private static final String JAVA_REFERRED_PRJ_NAME = "testJavaReferred";
	private static final String PLUGIN_PRJ_NAME = "testPlugin";
	private static final String PLUGIN_PRJ_LOCATION = "resources/testPlugin.zip";
	private static final String PLUGIN_PRJ_CUSTOM_HEADERS_PRJ_NAME = "testPluginCustomHeaders";
	private static final String PLUGIN_PRJ_CUSTOM_HEADERS_LOCATION = "resources/testPluginCustomHeaders.zip";
	private static final String SIMPLE_PRJ_COPY_LOCATION = "resources/testSimpleCopy.zip";
	private static final String SIMPLE_PRJ_COPY_NAME = "testSimpleCopy";
	private static final String JAVA_PRJ_COPY_LOCATION = "resources/testJavaCopy.zip";
	private static final String JAVA_PRJ_COPY_NAME = "testJavaCopy";
	private static final String WEB_PRJ_COPY_NAME = "testWebCopy";
	private static final String WEB_PRJ_COPY_LOCATION = "resources/testWebCopy.zip";
	private static final String WEB_CONVERTED_PRJ_NAME = "testWebConverted";
	private static final String WEB_CONVERTED_PRJ_LOCATION = "resources/testWebConverted.zip";
	private static final String JAVA_CONVERTED_PRJ_LOCATION = "resources/testJavaConverted.zip";
	private static final String JAVA_CONVERTED_PRJ_NAME = "testJavaConverted";
	private static final String SIMPLE_CONVERTED_PRJ_LOCATION = "resources/testSimpleConverted.zip";
	private static final String SIMPLE_CONVERTED_PRJ_NAME = "testSimpleConverted";
	private static final String PLUGIN_CONVERTED_PRJ_LOCATION = "resources/testPluginConverted.zip";
	private static final String PLUGIN_CONVERTED_PRJ_NAME = "testPluginConverted";
	private static final String JAVA_2_SRC_FOLDERS = "resources/testJava2SrcFolders.zip";
	private static final String JAVA_2_SRC_FOLDERS_NAME = "_testJava2SrcFolders";
	private static final String JAVA_NO_SRC_FOLDERS = "resources/testJavaNoSrcFolder.zip";
	private static final String JAVA_NO_SRC_FOLDERS_NAME = "_testJavaNoSrcFolder";
	private static final String SIMPLE_WITH_OSGI_MANIFEST_PRJ_LOCATION = "resources/testSimpleWithOSGiManifest.zip";
	private static final String SIMPLE_WITH_OSGI_MANIFEST_PRJ_NAME = "testSimpleWithOSGiManifest";
	private static final String JAVA_WITH_OSGI_MANIFEST_PRJ_LOCATION = "resources/testJavaWithOSGiManifest.zip";
	private static final String JAVA_WITH_OSGI_MANIFEST_PRJ_NAME = "testJavaWithOSGiManifest";
	private static final String WEB_WITH_OSGI_MANIFEST_PRJ_LOCATION = "resources/testWebWithOSGiManifest.zip";
	private static final String WEB_WITH_OSGI_MANIFEST_PRJ_NAME = "testWebWithOSGiManifest";
	
	@Before
	public void cleanUpWorkspace() throws Exception {
		deleteAllProjects();
		waitOnJobs();
	}
	
	@After
	public void waitJobs() throws Exception {
		// Wait for all validation jobs to end before ending test....
		waitOnJobs();
	}

	@Test
	public void convertSimpleProject() throws Exception {
		IProject simpleProject = importProjectInWorkspace(SIMPLE_PRJ_LOCATION, SIMPLE_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { simpleProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(simpleProject);
		
    	checkSimpleProject(SIMPLE_PRJ_NAME, "TestSimple", null, "1.0.0.qualifier", description);
	}

	@Test
	public void convertSimpleProjectCustomHeaders() throws Exception {
		IProject simpleProject = importProjectInWorkspace(SIMPLE_PRJ_COPY_LOCATION, SIMPLE_PRJ_COPY_NAME);
    	OSGiBundleFacetInstallConfig osgiBundleFacetInstallConfig = setupOSGiBundleFacetInstallConfig("customSymbolicName", "CustomBundleName", "customVendor", "1.0.1.qualifier");
		IFacetedProject fproj = ProjectFacetsManager.create(simpleProject, true, monitor);
		fproj.installProjectFacet(OSGI_BUNDLE_FACET_42, osgiBundleFacetInstallConfig, monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(simpleProject);
		
    	checkSimpleProject("customSymbolicName", "CustomBundleName", "customVendor", "1.0.1.qualifier", description);
	}

	@Test
	public void convertSimpleProjectWithOSGiManifest() throws Exception {
		IProject simpleProject = importProjectInWorkspace(SIMPLE_WITH_OSGI_MANIFEST_PRJ_LOCATION, SIMPLE_WITH_OSGI_MANIFEST_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { simpleProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(simpleProject);
		
    	checkSimpleProject("mybundle", "My Bundle", "My Company", "1.2.3", description);
	}
	
	@Test
	public void convertJavaProject() throws Exception {

		IProject javaProject = importProjectInWorkspace(JAVA_PRJ_LOCATION, JAVA_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { javaProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(javaProject);
		
    	checkJavaProject(javaProject, JAVA_PRJ_NAME, "TestJava", null, "1.0.0.qualifier", new String[] { "javapack", "javapack1" }, description);
	}

	@Test
	public void convertJavaProjectCustomHeaders() throws Exception {
		IProject javaProject = importProjectInWorkspace(JAVA_PRJ_COPY_LOCATION, JAVA_PRJ_COPY_NAME);
    	OSGiBundleFacetInstallConfig osgiBundleFacetInstallConfig = setupOSGiBundleFacetInstallConfig("customSymbolicName", "CustomBundleName", "customVendor", "1.0.1.qualifier");
		IFacetedProject fproj = ProjectFacetsManager.create(javaProject, true, monitor);
		fproj.installProjectFacet(OSGI_BUNDLE_FACET_42, osgiBundleFacetInstallConfig, monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(javaProject);
		
    	checkJavaProject(javaProject, "customSymbolicName", "CustomBundleName", "customVendor", "1.0.1.qualifier", new String[] { "javapack", "javapack1" }, description);
	}

	@Test
	public void convertJavaProjectWithOSGiManifest() throws Exception {
		IProject javaProject = importProjectInWorkspace(JAVA_WITH_OSGI_MANIFEST_PRJ_LOCATION, JAVA_WITH_OSGI_MANIFEST_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { javaProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(javaProject);
		
    	checkJavaProject(javaProject, "mybundle", "My Bundle", "My Company", "1.2.3", new String[] { "javapack", "javapack1" }, description);
	}
	
	
	@Test
	public void convertJavaProjectNoSrcFolder() throws Exception {
		IProject javaProject = importProjectInWorkspace(JAVA_NO_SRC_FOLDERS, JAVA_NO_SRC_FOLDERS_NAME);
		new ConvertProjectsToBundlesOperation(new IProject[] { javaProject }).run(monitor);
		IBundleProjectDescription description = getBundleProjectDescription(javaProject);
		IBundleClasspathEntry[] bundleClasspath = description.getBundleClasspath();
		assertNotNull(bundleClasspath);
		//one item with null src and bin attributes expected
		Assert.assertEquals("one item with null src attribute expected", 1, bundleClasspath.length);
		Assert.assertNull("item with null source attribute expected", bundleClasspath[0].getSourcePath());
    	checkSimpleProject(JAVA_NO_SRC_FOLDERS_NAME, JAVA_NO_SRC_FOLDERS_NAME, null, "1.0.0.qualifier", description);
		Assert.assertTrue(hasPluginDependenciesCP(javaProject));
	}
	
	@Test
	public void convertJavaProject2SrcFolders() throws Exception {
		IProject javaProject = importProjectInWorkspace(JAVA_2_SRC_FOLDERS, JAVA_2_SRC_FOLDERS_NAME);
		new ConvertProjectsToBundlesOperation(new IProject[]{javaProject}).run(monitor);
		IBundleProjectDescription description = getBundleProjectDescription(javaProject);
		IBundleClasspathEntry[] bundleClasspath = description.getBundleClasspath();
		assertNotNull(bundleClasspath);
		//one item with null src and bin attributes expected
		Assert.assertEquals("one item with null src attributes expected", 2, bundleClasspath.length);
		Assert.assertFalse("both items should be different (src and src2)", bundleClasspath[0].getSourcePath().lastSegment().equals(bundleClasspath[1].getSourcePath().lastSegment()));
		Assert.assertTrue("entry should be either src or src1, but was: " + bundleClasspath[0].getSourcePath().lastSegment(), "src".equals(bundleClasspath[0].getSourcePath().lastSegment()) || "src2".equals(bundleClasspath[0].getSourcePath().lastSegment()));
		Assert.assertTrue("entry should be either src or src1, but was: " + bundleClasspath[1].getSourcePath().lastSegment(), "src".equals(bundleClasspath[1].getSourcePath().lastSegment()) || "src2".equals(bundleClasspath[1].getSourcePath().lastSegment()));
    	checkSimpleProject(JAVA_2_SRC_FOLDERS_NAME, JAVA_2_SRC_FOLDERS_NAME, null, "1.0.0.qualifier", description);
		Assert.assertTrue(hasPluginDependenciesCP(javaProject));
	}
	
	@Test
	public void convertPluginProject() throws Exception {
		IProject pluginProject = importProjectInWorkspace(PLUGIN_PRJ_LOCATION, PLUGIN_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { pluginProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(pluginProject);
		
    	checkJavaProject(pluginProject, PLUGIN_PRJ_NAME, "TestPlugin", null, "1.0.0.qualifier", new String[] { "javapack", "javapack1", "testplugin" }, description);

    	IPackageImportDescription[] packageImports = description.getPackageImports();
    	Assert.assertNotNull(packageImports);
		List<String> packageImportStrings = new ArrayList<String>();
		for (IPackageImportDescription currPackageImportDescription : packageImports) {
			packageImportStrings.add(currPackageImportDescription.getName());
		}
    	Assert.assertTrue(packageImportStrings.contains("org.osgi.framework"));
    	
	}

	@Test
	public void convertPluginProjectCustomHeaders() throws Exception {
		IProject pluginProject = importProjectInWorkspace(PLUGIN_PRJ_CUSTOM_HEADERS_LOCATION, PLUGIN_PRJ_CUSTOM_HEADERS_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { pluginProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(pluginProject);

    	IPackageImportDescription[] packageImports = description.getPackageImports();
    	Assert.assertNotNull(packageImports);
		List<String> packageImportStrings = new ArrayList<String>();
		for (IPackageImportDescription currPackageImportDescription : packageImports) {
			packageImportStrings.add(currPackageImportDescription.getName());
		}
		Assert.assertTrue(packageImportStrings.contains("org.osgi.framework"));

    	checkJavaProject(pluginProject, "customSymbolicName", "CustomBundleName", "CustomProvider", "1.0.1.qualifier", new String[] { "javapack", "javapack1", "testplugincustomheaders" }, description);
    	
	}
	
	@Test
	public void convertWebProject() throws Exception {
		IProject webProject = importProjectInWorkspace(WEB_PRJ_LOCATION, WEB_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { webProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(webProject);
		
    	checkWebProject(webProject, WEB_PRJ_NAME, "TestWeb", null, "1.0.0.qualifier", new String[] { "test", "test1" }, "/" + WEB_PRJ_NAME, description);
	}
	
	@Test
	public void convertWebProjectWithOSGiManifest() throws Exception {
		IProject webProject = importProjectInWorkspace(WEB_WITH_OSGI_MANIFEST_PRJ_LOCATION, WEB_WITH_OSGI_MANIFEST_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { webProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(webProject);
		
    	// check that the customized headers in the existing OSGi manifest are not modified
    	checkWebProject(webProject, "mywab", "My WAB", "My Company", "1.2.3", new String[] { "test", "test1" }, "/my-wab", description);
	}
	
	
	@Test
	public void convertJPAProject() throws Exception {
		IProject jpaProject = importProjectInWorkspace(JPA_PRJ_LOCATION, JPA_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { jpaProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(jpaProject);
		
    	checkJPAProject(jpaProject, JPA_PRJ_NAME, "TestJPA", null, "1.0.0.qualifier", new String[] { "test" }, description);
	}
	
	@Test
	public void convertJPAProjectWithUtilityFacet() throws Exception {
		IProject jpaProject = importProjectInWorkspace(JPA_UTILITY_PRJ_LOCATION, JPA_UTILITY_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { jpaProject }).run(monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(jpaProject);
		
    	checkJPAProject(jpaProject, JPA_UTILITY_PRJ_NAME, "TestJPAwithUtility", null, "1.0.0.qualifier", new String[] { "test" }, description);
	}
	
	@Test
	public void convertWebProjectCustomHeaders() throws Exception {
		IProject webProject = importProjectInWorkspace(WEB_PRJ_COPY_LOCATION, WEB_PRJ_COPY_NAME);
		
    	OSGiBundleFacetInstallConfig osgiBundleFacetInstallConfig = setupOSGiBundleFacetInstallConfig("customSymbolicName", "CustomBundleName", "customVendor", "1.0.1.qualifier");
		IFacetedProject fproj = ProjectFacetsManager.create(webProject, true, monitor);
		fproj.installProjectFacet(OSGI_BUNDLE_FACET_42, osgiBundleFacetInstallConfig, monitor);
    	
    	IBundleProjectDescription description = getBundleProjectDescription(webProject);
		
    	checkWebProject(webProject, "customSymbolicName", "CustomBundleName", "customVendor", "1.0.1.qualifier", new String[] { "test", "test1" }, "/customWebContext", description);
	}
	
	@Test
	public void convertWebReferringJavaProjects() throws Exception {
		IProject webProject = importProjectInWorkspace(WEB_REFERRING_JAVA_PRJ_LOCATION, WEB_REFERRING_JAVA_PRJ_NAME);
		IProject javaProject = importProjectInWorkspace(JAVA_REFERRED_PRJ_LOCATION, JAVA_REFERRED_PRJ_NAME);
    	new ConvertProjectsToBundlesOperation(new IProject[] { webProject, javaProject }).run(monitor);
    	
    	IBundleProjectDescription webPrjDescription = getBundleProjectDescription(webProject);
    	IBundleProjectDescription javaPrjDescription = getBundleProjectDescription(javaProject);
		
    	checkWebProject(webProject, WEB_REFERRING_JAVA_PRJ_NAME, "TestWebReferringJava", null, "1.0.0.qualifier", new String[] { "test", "test1" }, "/" + WEB_REFERRING_JAVA_PRJ_NAME, webPrjDescription);
    	checkJavaProject(javaProject, JAVA_REFERRED_PRJ_NAME, "TestJavaReferred", null, "1.0.0.qualifier", new String[] { "javapack", "javapack1" }, javaPrjDescription);
    	
    	//the web projects uses a class from the java project. 
    	//Check that the corresponding package from the java project is available as imported package in the web project
    	boolean hasPackageImportForTheReferredJavaClass = false;
    	IPackageImportDescription[] packageImports = webPrjDescription.getPackageImports();
    	for (int i = 0; i < packageImports.length; i++) {
			IPackageImportDescription currPackageImportDescription = packageImports[i];
			if (currPackageImportDescription.getName().equals("javapack")) {
				hasPackageImportForTheReferredJavaClass = true;
				break;
			}
		}
    	Assert.assertTrue(hasPackageImportForTheReferredJavaClass);
	}

	@Test
	public void uninstallOSGiFacetFromWebProject() throws Exception {
		IProject webProject = importProjectInWorkspace(WEB_CONVERTED_PRJ_LOCATION, WEB_CONVERTED_PRJ_NAME);
		IFacetedProject fproj = ProjectFacetsManager.create(webProject, true, monitor);
		OSGiBundleFacetUninstallConfig config = new OSGiBundleFacetUninstallConfig();
		config.setStrategy(OSGiBundleFacetUninstallStrategy.FACET_AND_PLUGIN_NATURE_AND_MANIFEST);
		fproj.uninstallProjectFacet(OSGI_BUNDLE_FACET_42, config, monitor);
		Assert.assertFalse(webProject.hasNature(IBundleProjectDescription.PLUGIN_NATURE));
		Assert.assertFalse(hasBuildSpec(webProject, PDE.MANIFEST_BUILDER_ID));
		Assert.assertFalse(hasBuildSpec(webProject, PDE.SCHEMA_BUILDER_ID));
		Assert.assertFalse(hasPluginDependenciesCP(webProject));
		IFile buildPropertiesFile = webProject.getFile("WebContent/" + BUILD_PROPERTIES);
		Assert.assertFalse(buildPropertiesFile.exists());
	}

	@Test
	public void uninstallOSGiFacetFromJavaProject() throws Exception {
		IProject javaProject = importProjectInWorkspace(JAVA_CONVERTED_PRJ_LOCATION, JAVA_CONVERTED_PRJ_NAME);
		IFacetedProject fproj = ProjectFacetsManager.create(javaProject, true, monitor);
		OSGiBundleFacetUninstallConfig config = new OSGiBundleFacetUninstallConfig();
		config.setStrategy(OSGiBundleFacetUninstallStrategy.FACET_AND_PLUGIN_NATURE_AND_MANIFEST);
		fproj.uninstallProjectFacet(OSGI_BUNDLE_FACET_42, config, monitor);
		Assert.assertFalse(javaProject.hasNature(IBundleProjectDescription.PLUGIN_NATURE));
		Assert.assertFalse(hasBuildSpec(javaProject, PDE.MANIFEST_BUILDER_ID));
		Assert.assertFalse(hasBuildSpec(javaProject, PDE.SCHEMA_BUILDER_ID));
		Assert.assertFalse(hasPluginDependenciesCP(javaProject));
		IFile buildPropertiesFile = javaProject.getFile(BUILD_PROPERTIES);
		Assert.assertFalse(buildPropertiesFile.exists());
	}

	@Test
	public void uninstallOSGiFacetFromPluginProject() throws Exception {
		IProject pluginProject = importProjectInWorkspace(PLUGIN_CONVERTED_PRJ_LOCATION, PLUGIN_CONVERTED_PRJ_NAME);
		IFacetedProject fproj = ProjectFacetsManager.create(pluginProject, true, monitor);
		OSGiBundleFacetUninstallConfig config = new OSGiBundleFacetUninstallConfig();
		config.setStrategy(OSGiBundleFacetUninstallStrategy.FACET_ONLY);
		fproj.uninstallProjectFacet(OSGI_BUNDLE_FACET_42, config, monitor);
		Assert.assertTrue(pluginProject.hasNature(IBundleProjectDescription.PLUGIN_NATURE));
		Assert.assertTrue(hasPluginDependenciesCP(pluginProject));
		IFile buildPropertiesFile = pluginProject.getFile(BUILD_PROPERTIES);
		Assert.assertTrue(buildPropertiesFile.exists());
	}
	
	@Test
	public void uninstallOSGiFacetFromSimpleProject() throws Exception {
		IProject simpleProject = importProjectInWorkspace(SIMPLE_CONVERTED_PRJ_LOCATION, SIMPLE_CONVERTED_PRJ_NAME);
		IFacetedProject fproj = ProjectFacetsManager.create(simpleProject, true, monitor);
		OSGiBundleFacetUninstallConfig config = new OSGiBundleFacetUninstallConfig();
		config.setStrategy(OSGiBundleFacetUninstallStrategy.FACET_AND_PLUGIN_NATURE_AND_MANIFEST);
		fproj.uninstallProjectFacet(OSGI_BUNDLE_FACET_42, config, monitor);
		Assert.assertFalse(simpleProject.hasNature(IBundleProjectDescription.PLUGIN_NATURE));
		Assert.assertFalse(hasBuildSpec(simpleProject, PDE.MANIFEST_BUILDER_ID));
		Assert.assertFalse(hasBuildSpec(simpleProject, PDE.SCHEMA_BUILDER_ID));
		IFile buildPropertiesFile = simpleProject.getFile(BUILD_PROPERTIES);
		Assert.assertFalse(buildPropertiesFile.exists());
	}

	@Test
	public void createJPAProject() throws Exception {     
		IFacetedProjectWorkingCopy fProject = FacetedProjectFramework.createNewProject();
		fProject.setProjectName(JPA_CREATE_PRJ_NAME);
		HashSet<IProjectFacetVersion> facets = getFacets(new String[] { "java", "jpt.jpa", "osgi.bundle" });
		fProject.setProjectFacets(facets);
		fProject.commitChanges(monitor);
		checkMetaInf(fProject.getProject());
	}
	
	@Test
	public void createJPAUtilityProject() throws Exception {     
		IFacetedProjectWorkingCopy fProject = FacetedProjectFramework.createNewProject();
		fProject.setProjectName(JPA_UTILITY_CREATE_PRJ_NAME);
		HashSet<IProjectFacetVersion> facets = getFacets(new String[] { "java", "jpt.jpa", "jst.utility", "osgi.bundle" });
		fProject.setProjectFacets(facets);
		fProject.commitChanges(monitor);
		checkMetaInf(fProject.getProject());
	}
	
	private void checkWebProject(IProject project, String expectedSymbolicName, String expectedBundleName, String expectedVendor, String expectedVersion, String[] expectedPackageExports, String expectedWebContextPath, IBundleProjectDescription description) throws JavaModelException {
		checkJavaProject(project, expectedSymbolicName, expectedBundleName, expectedVendor, expectedVersion, expectedPackageExports, description);
		checkWebPackageImports(description);
		Assert.assertEquals("2", description.getHeader(Constants.BUNDLE_MANIFESTVERSION));
		checkLaunchShortcuts(description);
		Assert.assertEquals(expectedWebContextPath, description.getHeader(WEB_CONTEXT_PATH_HEADER));
		IPath[] binIncludes = description.getBinIncludes();
		Assert.assertTrue(binIncludes.length == 1);
		Assert.assertEquals("WEB-INF/", binIncludes[0].toString());
		IBundleClasspathEntry[] bundleClasspath = description.getBundleClasspath();
		Assert.assertEquals(1, bundleClasspath.length);
		Assert.assertNull(bundleClasspath[0].getBinaryPath());
		Assert.assertEquals("src/", bundleClasspath[0].getSourcePath().toPortableString());
		Assert.assertEquals("WEB-INF/classes/", bundleClasspath[0].getLibrary().toPortableString());
	}
		
	private void checkJPAProject(IProject project, String expectedSymbolicName, String expectedBundleName, String expectedVendor, String expectedVersion, String[] expectedPackageExports, IBundleProjectDescription description) throws JavaModelException {
		checkJavaProject(project, expectedSymbolicName, expectedBundleName, expectedVendor, expectedVersion, expectedPackageExports, description);
		checkJPAPackageImports(description);
		Assert.assertEquals("2", description.getHeader(Constants.BUNDLE_MANIFESTVERSION));
		IBundleClasspathEntry[] bundleClasspath = description.getBundleClasspath();
		Assert.assertEquals(1, bundleClasspath.length);
		Assert.assertNull(bundleClasspath[0].getBinaryPath());
		Assert.assertEquals("src/", bundleClasspath[0].getSourcePath().toPortableString());
		IPath outputFolder = description.getDefaultOutputFolder();
		Assert.assertEquals("build/classes", outputFolder.toString());			
		checkMetaInf(project);
	}

	private void checkMetaInf(IProject project) {
		Assert.assertTrue(project.getFolder("/META-INF/").exists());
		Assert.assertTrue(project.getFile("/META-INF/MANIFEST.MF").exists());
		Assert.assertTrue(project.getFile("/META-INF/persistence.xml").exists());		
		Assert.assertFalse(project.getFolder("/src/META-INF/").exists());	
		Assert.assertFalse(project.getFile("/src/META-INF/MANIFEST.MF").exists());
		Assert.assertFalse(project.getFile("/src/META-INF/persistence.xml").exists());
	}

	private void checkJavaProject(IProject project, String expectedSymbolicName, String expectedBundleName, String expectedVendor, String expectedVersion, String[] expectedPackageExports, IBundleProjectDescription description) throws JavaModelException {
		checkSimpleProject(expectedSymbolicName, expectedBundleName, expectedVendor, expectedVersion, description);
		Assert.assertTrue(hasPluginDependenciesCP(project));
		checkPackageExports(expectedPackageExports, description);
	}

	private boolean hasPluginDependenciesCP(IProject project) throws JavaModelException {
		IJavaProject javaProject = JavaCore.create(project);
		IClasspathEntry[] entries = javaProject.getRawClasspath();
		boolean hasPluginDependeciesCP = false;
		for (int i = 0; i < entries.length; i++) {
			IClasspathEntry entry = entries[i];
			if (PDECore.REQUIRED_PLUGINS_CONTAINER_PATH.equals(entry.getPath())) {
				hasPluginDependeciesCP = true;
				break;
			}
		}
		return hasPluginDependeciesCP;
	}

	private void checkSimpleProject(String expectedSymbolicName, String expectedBundleName, String expectedVendor, String expectedVersion, IBundleProjectDescription description) {
		Assert.assertEquals(expectedSymbolicName, description.getSymbolicName());
		Assert.assertEquals(expectedBundleName, description.getBundleName());
		Assert.assertEquals(expectedVersion, description.getBundleVersion().toString());
		Assert.assertEquals(expectedVendor, description.getBundleVendor());
		String[] natureIds = description.getNatureIds();
		Assert.assertTrue(Arrays.asList(natureIds).contains(IBundleProjectDescription.PLUGIN_NATURE));
	}

	private void checkLaunchShortcuts(IBundleProjectDescription description) {
		String[] launchShortcuts = description.getLaunchShortcuts();
		List<String> launchShortcutsList = Arrays.asList(launchShortcuts);
		Assert.assertTrue(launchShortcutsList.contains("org.eclipse.pde.ui.EquinoxLaunchShortcut"));
		Assert.assertTrue(launchShortcutsList.contains("org.eclipse.wst.server.launchShortcut"));
		Assert.assertEquals(2, launchShortcuts.length);
	}

	private void checkPackageExports(String[] expectedPackageExports, IBundleProjectDescription description) {
		IPackageExportDescription[] packageExports = description.getPackageExports();
		Assert.assertNotNull(packageExports);
		List<String> packageExportStrings = new ArrayList<String>();
		for (IPackageExportDescription currPackageExportDescription : packageExports) {
			packageExportStrings.add(currPackageExportDescription.getName());
		}
		Assert.assertEquals(expectedPackageExports.length, packageExports.length);
		List<String> expectedPackageExportList = Arrays.asList(expectedPackageExports);
		Assert.assertTrue(packageExportStrings.containsAll(expectedPackageExportList));
	}

	private void checkWebPackageImports(IBundleProjectDescription description) {
		IPackageImportDescription[] packageImports = description.getPackageImports();
		List<String> packageImportStrings = new ArrayList<String>();
		for (IPackageImportDescription currPackageImportDescription : packageImports) {
			packageImportStrings.add(currPackageImportDescription.getName());
		}
		Assert.assertTrue(packageImportStrings.contains("javax.servlet"));
		Assert.assertTrue(packageImportStrings.contains("javax.servlet.http"));
		Assert.assertTrue(packageImportStrings.contains("javax.servlet.jsp"));
		Assert.assertTrue(packageImportStrings.contains("javax.servlet.jsp.el"));
		Assert.assertTrue(packageImportStrings.contains("javax.servlet.jsp.tagext"));
		Assert.assertTrue(packageImportStrings.contains("javax.el"));
	}
	
	private void checkJPAPackageImports(IBundleProjectDescription description) {
		IPackageImportDescription[] packageImports = description.getPackageImports();
		List<String> packageImportStrings = new ArrayList<String>();
		for (IPackageImportDescription currPackageImportDescription : packageImports) {
			packageImportStrings.add(currPackageImportDescription.getName());
		}
		Assert.assertTrue(packageImportStrings.contains("javax.persistence"));
	}
	
	private OSGiBundleFacetInstallConfig setupOSGiBundleFacetInstallConfig(String symbolicName, String bundleName, String vendor, String version) throws CoreException {
		
		OSGiBundleFacetInstallConfig osgiBundleFacetInstallConfig = new OSGiBundleFacetInstallConfig() {
			
			@Override
			public void setFacetedProjectWorkingCopy(IFacetedProjectWorkingCopy fpjwc) {
				//do nothing
			}
			
		};
    	osgiBundleFacetInstallConfig.getSymbolicNameValue().setValue(symbolicName);
    	osgiBundleFacetInstallConfig.getNameValue().setValue(bundleName);
    	osgiBundleFacetInstallConfig.getVendorValue().setValue(vendor);
    	osgiBundleFacetInstallConfig.getVersionValue().setValue(version);
    	
		return osgiBundleFacetInstallConfig;
		
	}
	
	private IProject importProjectInWorkspace(String projectZipLocation, String projectName) throws IOException, CoreException{
		String absolutePathToMavenProject = System.getProperty("user.dir");
		String localZipPath = absolutePathToMavenProject + IPath.SEPARATOR + projectZipLocation;
		ProjectUnzipUtil util = new ProjectUnzipUtil(new Path(localZipPath), new String[] {projectName});
		Assert.assertTrue(util.createProjects());
		return ResourcesPlugin.getWorkspace().getRoot().getProject(projectName);
	}
	
	private boolean hasBuildSpec(IProject project, String builderId) throws CoreException {
		ICommand[] commands = project.getDescription().getBuildSpec();
		for (ICommand command : commands) {
			if (command.getBuilderName().equals(builderId)) {
				return true;
			}
		}
		return false;
	}
	
	private HashSet<IProjectFacetVersion> getFacets(String[] facetNames) {
		HashSet<IProjectFacetVersion> facets = new HashSet<IProjectFacetVersion>();
		for(int i=0; i<facetNames.length; i++) {
			IProjectFacet aFacet = ProjectFacetsManager.getProjectFacet(facetNames[i]);
			IProjectFacetVersion aFacetVersion = aFacet.getDefaultVersion();
			facets.add(aFacetVersion);	
		}
		return facets;
	}
			
}
